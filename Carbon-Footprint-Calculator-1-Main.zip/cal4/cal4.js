var Kwh = document.querySelector("#KWH")


function calculate() {
  
  var Select = document.querySelector(".Selection")
  
	 console.log('h')
	 var Tonnes_1 = (0.02 / 100)
	 var Cost_1 = (0.25 / 100)
	 var Tonnes = document.querySelector(".tonnes1")
	 var Cost = document.querySelector(".cost1")
	 var Inner_kwh = parseInt(Kwh.value)
	 var Tonnes_cal = Inner_kwh * Tonnes_1
	 var Cost_cal = Inner_kwh * Cost_1
  
	Tonnes.textContent = Tonnes_cal;
	Cost.textContent = Cost_cal; 
}
function myFunction(){
  window.open("https://carbon-footprint-calculator-5.shadowgaming31.repl.co" , "_self")
}