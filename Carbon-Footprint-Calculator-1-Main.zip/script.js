var Kwh = document.querySelector("#KWH")


function calculate() {
	console.log('h')
	var Tonnes_1 = (0.037 / 100)
	var Cost_1 = (0.46 / 100)
	var Tonnes = document.querySelector(".tonnes1")
	var Cost = document.querySelector(".cost1")
	var Inner_kwh = parseInt(Kwh.value)
	var Tonnes_cal = Inner_kwh * Tonnes_1
	var Cost_cal = Inner_kwh * Cost_1
  
	Tonnes.textContent = Tonnes_cal;
	Cost.textContent = Cost_cal;
}
function myFunction(){
  window.open("https://carbon-footprint-calculator-2.shadowgaming31.repl.co" , "_self")
}

