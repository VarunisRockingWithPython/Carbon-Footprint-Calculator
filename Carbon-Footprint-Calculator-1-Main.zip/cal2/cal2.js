var Kwh = document.querySelector("#KWH")


function calculate() {
  var somet = document.querySelector("#some")
  var Select = document.querySelector(".Selection")
  if (Select.value == "Propane"){
	 console.log('h')
	 var Tonnes_1 = (0.576 / 100)
	 var Cost_1 = (7.20 / 100)
	 var Tonnes = document.querySelector(".tonnes1")
	 var Cost = document.querySelector(".cost1")
	 var Inner_kwh = parseInt(Kwh.value)
	 var Tonnes_cal = Inner_kwh * Tonnes_1
	 var Cost_cal = Inner_kwh * Cost_1
  
	Tonnes.textContent = Tonnes_cal;
	Cost.textContent = Cost_cal; 
    
    
    }
  else if (Select.value == "Natural Gas"){
    
    somet.innerText = "CCF"
    var Tonnes_1 = (0.531 / 100)
	  var Cost_1 = (6.64 / 100)
	 var Tonnes = document.querySelector(".tonnes1")
	 var Cost = document.querySelector(".cost1")
	 var Inner_kwh = parseInt(Kwh.value)
	 var Tonnes_cal = Inner_kwh * Tonnes_1
	 var Cost_cal = Inner_kwh * Cost_1
  
	Tonnes.textContent = Tonnes_cal;
	Cost.textContent = Cost_cal;
  }
  else if (Select.value == "Oil") {
    console.log('h')
	 var Tonnes_1 = (1.016 / 100)
	 var Cost_1 = (12.70 / 100)
	 var Tonnes = document.querySelector(".tonnes1")
	 var Cost = document.querySelector(".cost1")
	 var Inner_kwh = parseInt(Kwh.value)
	 var Tonnes_cal = Inner_kwh * Tonnes_1
	 var Cost_cal = Inner_kwh * Cost_1
  
	Tonnes.textContent = Tonnes_cal;
	Cost.textContent = Cost_cal; 
  }
}
function myFunction(){
  window.open("https://carbon-footprint-calculator-3.shadowgaming31.repl.co" , "_self")
}
